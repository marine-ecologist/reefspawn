# Six years of demography data for 11 reef coral species

Joshua S. Madin<sup>1</sup>*,
Andrew H. Baird<sup>2</sup>,
Sean R. Connolly<sup>3</sup>,
Maria A. Dornelas<sup>4</sup>,
Mariana Álvarez-Noriega<sup>5</sup>,
Miguel Borges Da Costa Guint Barbosa<sup>6</sup>,
Shane A. Blowes<sup>7</sup>,
Paulina Cetina-Heredia<sup>8</sup>,
Alec P. Christie<sup>9</sup>,
Vivian Cumbo<sup>10</sup>,
Marcela Diaz<sup>11</sup>,
Madeleine Emms<sup>12</sup>,
Erin Graham<sup>13</sup>,
Dominique Hansen<sup>14</sup>,
Mizue Hisano<sup>15</sup>,
Emily Howells<sup>16</sup>,
Chao-Yang Kuo<sup>17</sup>,
Michael J. McWilliam<sup>18</sup>,
Caroline Palmer<sup>19</sup>,
James Tan Chun Hong<sup>20</sup>,
Theophilus Zhi En Teo<sup>21</sup>,
Rachel Woods<sup>22</sup>

*Correspondence and requests for materials should be addressed to Joshua S. Madin (email: jmadin@hawaii.edu).

1. Hawai'i Institute of Marine Biology, University of Hawai'i at Manoa, Kaneohe, HI, United States
2.

### Abstract

Scleractinian corals are colonial animals with a range of life history strategies that make up diverse species assemblages that contribute to coral reef growth. We tagged and tracked approximately 30 colonies from each of 11 species for six years (2009-2015) in order to measure their vital rates and competitive interactions on the reef crest at Trimodal Reef, Lizard Island, Australia. Pairs of species were chosen from five growth forms (massive [*Goniastrea pectinata* and *G. retiformis* ], digitate [*Acropora humilis* and *A. cf. digitifera* ], corymbose [*A. millepora* and *A. nasuta* ], tabular [*A. cytherea* and *A. hyacinthus* ] and arborescent [*A. robusta* and *A. intermedia* ]) where one species of the pair was locally rare and the other abundant. (An extra corymbose species, *A. spathulata* was included when it became apparent that *A. millepora* was too rare to work with on the reef crest, making the 11 species in total.) The tagged colonies were visited each year in the weeks prior to mass spawning. During visits, photographs were taken by two or more observers from directly above and on the horizontal plane with a scale plate to track planar area. Dead or missing colonies were recorded and new colonies tagged in order to maintain approximately 30 colonies per species throughout the six years of the study. In addition to tracking tagged corals, 30 fragments were collected from neighboring untagged colonies of each species for counting numbers of eggs per polyp (fecundity); and fragments of untagged colonies were brought into the laboratory where spawned eggs were collected for size and energy measurements. We also conducted surveys at the study site to generate size structure data for each species in several of the years. Each tagged colony photograph was digitized by at least two people. Therefore, we could examine sources of error in planar area for both photographers and outliners. Competitive interactions were recorded for a subset of species by measuring the margins of tagged colony outlines interacting with neighboring corals. The study was abruptly ended by Tropical Cyclone Nathan that killed all but nine of the over 300 tagged colonies in early 2015. Nonetheless, these data will be of use to other researchers interested in coral demography and coexistence, functional ecology, and parameterizing population, community and ecosystem models.

### Introduction

Instructions:
https://esajournals.onlinelibrary.wiley.com/hub/journal/19399170/resources/data_paper_inst_ecy

# Metadata
### Class I. Data set descriptors
##### A. Data set identity:

Title: Six years of demography data for 11 reef coral species.

### B. Data set and metadata identification codes: Suggested data set identity codes

##### Suggested data set identity codes:

- competition.csv
- egg_energy.csv
- fecundity.csv
- growth.csv
- polyp_density.csv
- size_structure.csv
- survival.csv
- trimodal.csv

### C. Data set description
##### Principal investigators:

1. Joshua S. Madin.
2. Andrew H. Baird.
3. Sean R. Connolly.
4. Maria A. Dornelas.

##### Abstract:

Scleractinian corals are colonial animals with a range of life history strategies that make up diverse species assemblages that contribute to coral reef growth. We tagged and tracked approximately 30 colonies from each of 11 species for six years (2009-2015) in order to measure their vital rates and competitive interactions on the reef crest at Trimodal Reef, Lizard Island, Australia. Pairs of species were chosen from five growth forms (massive [*Goniastrea pectinata* and *G. retiformis*], digitate [*Acropora humilis* and *A. cf. digitifera*], corymbose [*A. millepora* and *A. nasuta*], tabular [*A. cytherea* and *A. hyacinthus*] and arborescent [*A. robusta* and *A. intermedia*]) where one species of the pair was locally rare and the other abundant. (An extra corymbose species, *A. spathulata* was included when it became apparent that *A. millepora* was too rare to work with on the reef crest, making the 11 species in total.) The tagged colonies were visited each year in the weeks prior to mass spawning. During visits, photographs were taken by two or more observers from directly above and on the horizontal plane with a scale plate to track planar area. Dead or missing colonies were recorded and new colonies tagged in order to maintain approximately 30 colonies per species throughout the six years of the study. In addition to tracking tagged corals, 30 fragments were collected from neighboring untagged colonies of each species for counting numbers of eggs per polyp (fecundity); and fragments of untagged colonies were brought into the laboratory where spawned eggs were collected for size and energy measurements. We also conducted surveys at the study site to generate size structure data for each species in several of the years. Each tagged colony photograph was digitized by at least two people. Therefore, we could examine sources of error in planar area for both photographers and outliners. Competitive interactions were recorded for a subset of species by measuring the margins of tagged colony outlines interacting with neighboring corals. The study was abruptly ended by Tropical Cyclone Nathan that killed all but nine of the over 300 tagged colonies in early 2015. Nonetheless, these data will be of use to other researchers interested in coral demography and coexistence, functional ecology, and parametrizing population, community and ecosystem models.

### D. Key words:

Reef, coral, Scleractinia, growth, survivorship, mortality, fecundity, spawning, competition, demography, growth form

### E. Description:

# Class II. Research origin descriptors

### A. Overall project description

1. **Identity**: Six years of demography data for 11 reef coral species.
2. **Originators**: The Trimodal project was initiated by Joshua S. Madin, Andrew H. Baird, Sean R. Connolly and Maria A. Dornelas.  All other contributors helped in the field and lab throughout the project.
3. **Period of Study**: Data sampling occurred from 2008 to 2015. Data from the first year (2008) are not included due to observational inaccuracies and inconsistencies.
4. **Objectives**: There were many objectives of the Trimodal project, which centered about understanding subtle differences in reef coral demography that lead to coexistence and relative abundances in species-rich assemblages. Several of these objectives have already been published. The objective of this data paper is to make the data set avaiably to other reearchers to address other questions and for parameterising ecological models.
5. **Abstract**: Same as above.
6. **Sources of funding**: The compilation of this data set was supported by Australian Research Council Discovery Projects (DP0987892 to JSM; XXX to SRC), ARC Future Fellowships (FT110100609 to JSM; XXX to AHB), the John Templeton Foundation (XXX to MAD and JSM) and ...

### B. Specific subproject description

1. **Site description**:


### Files



> trimodal.csv

colony_id: Unique coral colony ID.
species: Coral species name.
spp: Coral species two-digit code.
year: Year of fieldtrip, which was at spawning time around October / November.
observation_id: Unique observation of the colony.
tag: Number from tag used to identify colony in the field.
image_id: A concatenation of various identifers for finding photos: the two-digit species code, tag number, fieldtrip ID (F3 was in 2009, F4 in 2010, and so on), the photo direction and number, photographer code, and the letter C is redundant and simply means the photo was corrected for barrel distortion before colony outlining.
photographer: Letter A-D designated to a photographer at the start of the fieldtrip. Letters were assigned arbitrarily each trip.
photograph: The photograph direction and number (T is top or planar view, T2 means a second photo was taken).
area_id: Unique ID for an outlined area from a particular photo.
area_outliner: The name of the outlining.
area_cm2: The outlined planar area of the colony in centimeters squared.
perimeter_cm: The colony perimeter in centimeters.
circularity: Circularity measured as the ratio between the perimeter of a circle with the area of the colony and the perimeter of the colony; so always less than 1 (which would be a perfectly circular colony). This measure should be treated carefully, because it is sensitive to the resolution and size of the colony in a picture.

tag: the tag number of the coral in the field.

> growth.csv

colony_id
spp
species
year
area_cm2
area_cm2_next

> survival.csv

colony_id
spp
species
year
area_cm2
surv

> competition.csv

colony_id
spp
species
year
area_cm2
competition_id
competition_number
competition_outliner_name
competition_taxon
competition_growthform
competition_type_old
competition_length_cm
competition
standoff
touch_flag
competition_type
outcome

> egg_energy.csv

id
year
species
spp
colony
egg
Carbon_ug_corrected
Nitrogen_ug
comment
area_cm2

> fecundity.csv

id
year
observer
species
spp
colony
branch
polyp
eggs
area_cm2
reproductive

> polyp_density.csv

id
spp
species
cm2
polyps
polyps_cm2

> size_structure.csv

spp
species
year
area_cm2

### Emails

Joshua S. Madin<sup>1</sup>*,
Andrew H. Baird<sup>2</sup>,
Sean R. Connolly<sup>3</sup>,
Maria A. Dornelas<sup>4</sup>,
Mariana Álvarez-Noriega<sup>4</sup>,
Miguel Borges Da Costa Guint Barbosa, mb334@st-andrews.ac.uk
Shane A. Blowes, shane.blowes@idiv.de
Paulina Cetina-Heredia, meyre@hpu.edu
Vivian Cumbo, vivian.cumbo@gmail.com
Marcela Diaz, marcediazj@gmail.com
Erin Graham, erin.graham@jcu.edu.au
Dominique Hansen, dom.hansen83@gmail.com
Mizue Hisano, mizue.jacobson@jcu.edu.au
Emily Howells, ehowells@uow.edu
Chao-Yang Kuo, cykuo.tw@gmail.com
Michael J. McWilliam
Caroline Palmer, carolinepalmer28@googlemail.com
James Tan Chun Hong, chtan.james@gmail.com
Theophilus Zhi En Teo, teozhien.62@gmail.com
Rachel Woods, rachael.maree.woods@gmail.com
Alex, apc58@cam.ac.uk
Madeleine Emms, mae47@cam.ac.uk
