# Data paper code

### Metadata

dat <- read.csv("output/growth.csv", as.is=TRUE)
names(dat)

### Figures


dat <- read.csv("output/growth.csv", as.is=TRUE)
dim(dat)
head(dat)
unique(dat$year)
table(dat$species)

par(mfrow=c(4, 3), mar=c(3, 3, 1, 1), oma=c(2, 2, 0, 0))

species <- sort(unique(dat$species))

for (s in 1:length(species)) {
# spp <- "AC"
  temp <- dat[dat$species==species[s],]

  plot(1,1, xlim=c(0, 6), ylim=c(-2, 1), type="n", axes=FALSE)
  abline(h=0, lty=2)
  if (s %in% c(9, 10, 11)) {
    axis(1)
  } else {
    axis(1, labels=NA)
  }
  if (s %in% c(1, 4, 7, 10)) {
    axis(2, at=seq(-2, 1), labels=10^seq(-2, 1), las=2)
  } else {
    axis(2, at=seq(-2, 1), labels=NA, las=2)
  }

  cols <- unique(temp$colony_id)
  for (i in cols) {
    temp2 <- temp[temp$colony_id==i,]
    temp2$year <- temp2$year - min(temp2$year) + 1
    temp2$delta <- log10(temp2$area_cm2_next / temp2$area_cm2[temp2$year==1])
  
    lines(c(0, temp2$year), c(0, temp2$delta), col=rgb(0,0,0,0.2))
  }
  mtext(substitute(italic(x), list(x=species[s])), 3, -1, adj=0.1, cex=0.8)
}
mtext("Years since tagged", outer=TRUE, side=1, line=0)
mtext("Magnitude growth since first tagged", outer=TRUE, side=2, line=0)

# Survival

sur <- read.csv("output/survival.csv", as.is=TRUE)

head(sur)


# fecundity
 
fec<-read.csv("output/fecundity.csv") # N per branch

head(fec)


# ----------------------------# mean polyp density
pd <- read.csv("output/polyp_density.csv")
pd.mean <- aggregate(list(polyps_cm2=pd$polyps_cm2),list(species=pd$species),mean)
pd.mean <- rbind(pd.mean, data.frame(species="Acropora millepora", polyps_cm2=pd.mean$polyps_cm2[pd.mean$species=="Acropora spathulata"])) # No Ami == use Asp



# --- Aggregate fecundity to colony-level
##################################
fec$polyps_cm2 <- pd.mean$polyps_cm2[match(fec$species, pd.mean$species)]
fec<-aggregate(.~id+species, fec[,c("id","area_cm2","eggs","species", "polyps_cm2")], mean)


#################################### 
# ---- remove F9 (hurricane/post hurricane)
unique(dat$year)
dat <- dat[!dat$year==2014,] 
sur <- sur[!sur$year==2015,]
sur$surv <- ifelse(sur$year==2014, NA, sur$surv)
unique(sur$year)


# -- Bad colonies
##################################
sur<-sur[!sur$colony_id==287,]
dat<-dat[!dat$colony_id==287,]


# --- All areas in log10 m2
##################################
fec$area <- log10(fec$area_cm2 /10000) 
dat$area <- log10(dat$area_cm2 / 10000) 
dat$area_next <- log10(dat$area_cm2_next / 10000) 
sur$area <- log10(sur$area_cm2 / 10000) 

# --- remove tiny colonies (<3cm diameter)
##################################
diam <- 3
min.area <- log10(pi*(diam/2/100)^2)
dat <- subset(dat, area > min.area)
sur <- subset(sur, area > min.area)
fec <- subset(fec, area > min.area)

# -- calculate model parameters
##################################

source("R/params.R")
params

#- plot size based models
##########################

library("ggplot2")
library("cowplot")

p1<-ggplot()+
  geom_jitter(data=fec, 
    aes(x= area, reproductive), 
      height=0.02, shape=21, col="grey")+
  geom_line(data=m.pred, 
    aes(area, pred, col=species))+
  theme_classic()

p2<-ggplot()+ 
  geom_point(data=fec[fec$reproductive==1, ], 
    aes(area, fecundity), 
      shape=21, col="grey")+
  geom_line(data=f.pred, aes(area, pred, col=species))+
  scale_y_log10()+
  theme_classic()

p3<-ggplot()+ 
  geom_abline(slope=1, linetype="dotted")+
  geom_point(data=dat, 
    aes(area, area_next), 
      shape=21, col="grey")+
  geom_line(data=g.pred, 
    aes(area, pred, col=species))+
 theme_classic()

p4<-ggplot()+ 
  geom_jitter(data=sur, 
    aes(area, surv), 
      shape=21, col="grey",height=0.02)+
  geom_line(data=s.pred, 
    aes(area, pred, col=species))+
 theme_classic()
 
p5<-ggplot()+
 geom_point(data=dat, aes(x=area, y=g_radius), col="grey", shape=21)+
     geom_line(data=r.pred, aes(x=area, y=pred, col=species))+
    theme_classic()

p6<-ggplot()+
  geom_point(data=pdat, 
    aes(x=area, y=pm_logit), 
       shape=21, col="grey")+
    geom_line(data=pdat, aes(x=area, y=logit(p_stasis), group=species), linetype="dotted")+
   geom_line(data=p.pred, 
     aes(x=area, y=pred, col=species))+
     theme_classic()

partheme <- theme(axis.text=element_text(size=7), axis.title=element_text(size=8),
plot.title=element_text(size=8, hjust=0.5, face="bold"), legend.title=element_blank(), legend.text=element_text(face="italic"))

xlab <- expression(log[10]*(area[~t]))

sp_cols <- c("#33a02c", "#a6cee3", "#b2df8a", "#1f78b4", "#6a3d9a", "#ffff99", "#ff7f00", "#cab2d6", "#fdbf6f", "#fb9a99", "#e31a1c")

model_plot <- plot_grid(plot_grid(
p1+guides(col="none")+partheme+ggtitle("reproductive maturity")+
labs(x=xlab,y="probability of maturity")+
scale_colour_manual(values=sp_cols), 
p2+guides(col="none")+partheme+ggtitle("fecundity")+
labs(x=xlab,y=expression("eggs per colony"))+
scale_colour_manual(values=sp_cols),
p3+guides(col="none")+partheme+ggtitle("growth rate")+
labs(x=xlab, y=expression(log[10]*(area[~t~+1])))+
scale_colour_manual(values=sp_cols),  
p4+guides(col="none")+partheme+ggtitle("survival rate")+
labs(x=xlab, y="annual survival rate")+
scale_colour_manual(values=sp_cols), 
p5+guides(col="none")+partheme+ggtitle("maximum growth")+
labs(x=xlab, y=expression(log[10]*(radial~growth)))+
scale_colour_manual(values=sp_cols),
p6+guides(col="none")+partheme+ggtitle("partial mortality")+
labs(x=xlab, y="logit(proportion area lost)")+
scale_colour_manual(values=sp_cols), 
nrow=2, align="hv", labels="AUTO", label_size=8),
get_legend(p1+partheme+scale_colour_manual(values=sp_cols)), rel_widths=c(1,0.2))
model_plot

ggsave("figs/model_plot.jpg", model_plot, height=110, width=200, units="mm")



