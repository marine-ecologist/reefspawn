

params <- data.frame(species=species)

#######################################
# MATURITY 
#######################################
fec$reproductive <- ifelse(fec$eggs>0, 1, 0) # reproductive status
m.int<-NULL
m.slp<-NULL
m.pred<-NULL
for(sp in species){
	sub<-fec[fec$species==sp,]
	m.mod<-glm(reproductive ~ area, family="binomial", data=sub) 
	m.int<-c(m.int, coef(m.mod)[1])
	m.slp<-c(m.slp, coef(m.mod)[2])
	new<-data.frame(area=seq(min(sub$area), max(sub$area), 0.1), 
	  species=sp)
	new$pred<-predict(m.mod, new, type="response")
	m.pred<-rbind(m.pred, new)
}
params$m.int<-m.int
params$m.slp<-m.slp

#######################################
# FECUNDITY  
#######################################
library("MASS")

fec$f.cm2<-fec$polyps_cm2*fec$eggs  # eggs per cm2
fec$fecundity<-round(fec$f.cm2*fec$area_cm2) # eggs per colony

f.int<-NULL
f.slp<-NULL
f.pred<-NULL
for(sp in species){
	sub<-fec[fec$species==sp & fec$reproductive==1,]
	f.mod<-glm.nb(fecundity ~ area, sub)
	f.int<-c(f.int, coef(f.mod)[1])
	f.slp<-c(f.slp, coef(f.mod)[2])
	new<-data.frame(area=seq(min(sub$area), max(sub$area), 0.1),
	species=sp)
	new$pred<-predict(f.mod, new, type="response")
	f.pred<-rbind(f.pred, new)
	}
params$f.int<-f.int
params$f.slp<-f.slp

#######################################
# GROWTH 
#######################################

g.int<-NULL
g.slp<-NULL
g.var<-NULL
g.pred<-NULL
for(sp in species){
	sub<-dat[dat$species==sp,]
	g.mod<-lm(area_next ~ area, data=sub) 
	g.int<-c(g.int, coef(g.mod)[1])
	g.slp<-c(g.slp, coef(g.mod)[2])
	g.var<-c(g.var, var(residuals(g.mod)))
	new<-data.frame(area=seq(min(sub$area), max(sub$area), 0.1),
	  species=sp)
	new$pred<-predict(g.mod, new, type="response")
	g.pred<-rbind(g.pred, new)
}
params$g.int<-g.int
params$g.slp<-g.slp
params$g.var<-g.var

#######################################
# SURVIVAL 
#######################################
sur$area_sq<-sur$area^2
sur<-sur[!is.na(sur$surv),]
#sur<-sur[sur$area>-3,]
s.int<-NULL
s.slp<-NULL
s.slp2<-NULL
s.pred<-NULL
for(sp in species){
	sub<-sur[sur$species==sp,]
	s.mod<-glm(surv ~ area, family="binomial", data=sub) 
	s.mod2<-glm(surv ~ area + area_sq, family="binomial", data=sub) 
	s.mod.c <- s.mod2
	s.int<-c(s.int, coef(s.mod.c)[1])
	s.slp<-c(s.slp, coef(s.mod.c)[2])
	s.slp2<-c(s.slp2, coef(s.mod.c)[3])
	new<-data.frame(area=seq(min(sub$area), max(sub$area), 0.1), 
	  species=sp)
	new$area_sq <- new$area^2
	new$pred<-predict(s.mod.c, new, type="response")
	s.pred<-rbind(s.pred, new)
	}
params$s.int<-s.int
params$s.slp<-s.slp
params$s.slp.2<-s.slp2

#######################################
# MAXIMUM GROWTH  
#######################################
library("quantreg")
dat$radius1<-sqrt(dat$area_cm2/pi)/100
dat$radius2<-sqrt(dat$area_cm2_next/pi)/100
dat$g_radius<-dat$radius2-dat$radius1

r.int<-NULL
r.slp<-NULL
r.err<-NULL
r.pred<-NULL
for(sp in species){
	sub<-dat[dat$species==sp,]
	r.mod <-rq(g_radius ~ 1 , data=sub, tau=0.98) # no slope
	r.int<-c(r.int, coef(r.mod)[1])
	r.err <- c(r.err, summary(r.mod, se='boot')$coef[[2]])
	new<-data.frame(area=seq(min(sub$area), max(sub$area), 0.1), 
	  species=sp)
	new$pred<-predict(r.mod, new, type="response")
	r.pred<-rbind(r.pred, new)
	}
params$r.int<-r.int
params$r.slp<-r.slp
params$r.err<-r.err

# Gre growth slope = Gpe
#################################### 
params[params$species=="Goniastrea retiformis", c("g.int", "g.slp","g.var")] <- params[params$species=="Goniastrea pectinata", c("g.int", "g.slp","g.var")]


#######################################
# PARTIAL MORTALITY  
#######################################
logit <- function(x) { log(x/(1-x)) }
inv.logit <- function(x) { exp(x)/(1+exp(x)) }

dat$max_g<-params$r.int[match(dat$species, params$species)] 
dat$max_area2<-pi*(dat$max_g + dat$radius1)^2 # eq. 2.1 
dat$p_mort<-  1 - ((dat$area_cm2_next/10000)/dat$max_area2) # eq. 2.2
dat$p_stasis<-  1 - ((dat$area_cm2/10000)/dat$max_area2) 
pdat<-subset(dat, p_mort>0.001) # less than max growth line
pdat$pm_logit <- logit(pdat$p_mort) 

p.int<-NULL
p.slp<-NULL
p.pred<-NULL
p.sig<-NULL
for(sp in species){
	sub<-pdat[pdat$species==sp,]
	p.mod<-lm(pm_logit ~ area , data=sub)
	p.int <- c(p.int, coef(p.mod)[[1]])
	p.slp <- c(p.slp, coef(p.mod)[[2]])
	p.sig <- c(p.sig, sigma(p.mod))
	new<-data.frame(area=seq(min(sub$area), max(sub$area), 0.1), 
	  species=sp)
	new$pred<-predict(p.mod, new, type="response")
	p.pred<-rbind(p.pred, new)
	}
params$p.int<-p.int
params$p.slp<-p.slp
params$p.sig<-p.sig

# Gre growth slope = Gpe
#################################### 
params[params$species=="Goniastrea retiformis", c("p.int", "p.slp","p.sig")] <- params[params$species=="Goniastrea pectinata", c("p.int", "p.slp","p.sig")]


