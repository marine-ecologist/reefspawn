
source("R/data_clean.R")
library("ggplot2")

#################### Funky growth plot
df<-dat
t0<-merge(aggregate(year~colony_id, data=df, min), df, 
          by=c("colony_id", "year"))
df$t0<-t0$area_cm2[match(df$colony_id, t0$colony_id)]
df <- df[do.call(order, df[c("colony_id", "year")]),]
row.names(df) <- NULL
df$year_rank <- with(df, ave(seq_along(colony_id), colony_id, FUN = seq_along))
t_end<-merge(aggregate(year~colony_id, data=df, max), df, by=c("colony_id", "year"))
df$t_end<-t_end$area_cm2[match(df$colony_id, t_end$colony_id)]
df$diff<-df$t_end-df$t0
df$net<-ifelse(df$diff>0, "Grow", "Shrink")
df$ratio_t0<-df$area_cm2/df$t0

# order
params$abundance<-ifelse(params$abundance_05<500, "Rare", 
                         ifelse(params$abundance_05>1500, "Dominant","Common"))
df$abun<-params$abundance[match(df$spp, params$spp)]
df$abun<-factor(df$abun, levels=c("Rare", "Common", "Dominant"))
df$morph<-params$morphology[match(df$spp, params$spp)]
df$morph<-factor(df$morph, levels=c("massive", "digitate", "corymbose","staghorn","tabular"))

# --------- 2 abun categories & merge AL/AM
df$abun2<-df$abun
df$abun2[df$abun2=="Dominant"]<-"Common"
df$abun2[df$abun2=="Common" & df$spp=="AS"]<-"Rare"
df$abun2[df$abun2=="Common" & df$spp=="AL"]<-"Rare"
df$spp2<-ifelse(df$spp=="AM" | df$spp=="AL", "AM/AL", df$spp)

# -------- plot
pdf("figs/funky_growth.pdf", width=8, height=4)

ggplot(df)+
  geom_line(aes(x=year_rank, y=ratio_t0, group=colony_id, col=net), size=0.2)+geom_text(data=unique(df[,c("spp2","morph","abun2")]), aes(x=2, y=10, label=spp2), size=2)+
  facet_grid(abun2~morph)+
  scale_colour_manual(values=c("grey20","red"))+
  scale_y_log10()+
  theme_classic()+
  theme(strip.background=element_blank(), legend.title=element_blank())+
  guides(colour="none")+
  xlab("Years since first observation")+
  ylab("Ratio to initial size")

dev.off()



