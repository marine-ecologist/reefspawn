# Data prep

rm(list = ls())

params <- read.csv("data/info.csv")

# Colony areas

obs <- read.csv("data/growth_mortality/trimodal_20201119.csv", as.is=TRUE)
obs <- obs[!is.na(obs$area_cm2),]

# Some after the fact dead and gone assignments (have areas, but wrong colonies)
obs <- obs[!obs$action=="dead",]
obs <- obs[!obs$action=="gone",]

# problem colonies (accidentally switch target colony, so removing post 2012 observations)
obs <- obs[!c(obs$colony_id==351 & obs$year > 2012), ]

# clean data - mm
obs<-unique(obs[,grepl("competition", colnames(obs))==FALSE] )
obs<-obs[!obs$photo_acceptable==0 & !obs$outline_acceptable==0,]

# merge "marked" colonies - mm
obs$photographer<-as.character(obs$photographer)
obs$photographer[is.na(obs$photographer)] <- "no_name"
merges<-obs[obs$marked==1,] # separate merges
dat_rm<-obs[!obs$marked==1,] # separate merges
merges[,c("image_id", "photograph", "area_id", "tag","circularity","perimeter_cm")]<-"merged" # prepare to sum
summed<-aggregate(area_cm2~., data=merges, sum) # find sum
summed[,c("circularity","perimeter_cm")]<-NA
obs<-rbind(dat_rm, summed[,colnames(dat_rm)]) # combine again
nrow(summed)

# export area data
head(obs)
colnames(obs)[2]<-"spp"
obs<-subset(obs, select=-c(outline_acceptable, photo_acceptable, marked, fieldtrip_id, action))
obs<-obs[order(obs$colony_id),]
obs$species<-params$species[match(obs$spp, params$spp)]
write.csv(obs, "output/trimodal.csv", row.names=FALSE)


# take the average of all photos 
# -- what's being averaged? 
# -- area measurments of each colony at each timepoint.
# -- areas come from multiple observer images 
# -- images can be outlines by multiple outliners
dat <- obs
dat <- aggregate(area_cm2 ~ colony_id + spp + species + year, mean, data=dat) 
dat <- dat[order(dat$colony_id),]


### ADD MORTALITY - mm
sdat <- dat
maxt<-aggregate(year~colony_id, sdat[!is.na(sdat$area_cm2),], max)
sdat$maxt<-maxt$year[match(sdat$colony_id, maxt$colony_id)]
sdat$surv<-ifelse(sdat$year==sdat$maxt, 0, 1)
sdat$surv<-ifelse(sdat$maxt==max(sdat$maxt) & sdat$year==max(sdat$maxt), NA, sdat$surv) # last census is NA (unknown)
sdat <- subset(sdat, select=-c(maxt))
head(sdat)

write.csv(sdat, "output/survival.csv", row.names=FALSE)

### ADD GROWTH

# do a joint to extract t, t+1 data
x <- dat
x$year <- x$year - 1
gdat <- merge(dat, x,  by=c("colony_id", "spp","species", "year"))
colnames(gdat)[5]<-"area_cm2"
colnames(gdat)[6]<-"area_cm2_next" 

gdat <- gdat[order(gdat$colony_id),]
write.csv(gdat, "output/growth.csv", row.names=FALSE)
head(gdat)

### ADD COMPETITION

com <- read.csv("data/competition/competition_lizard_checking_1.csv", as.is=TRUE)
com$year <- NA
com$year[com$fieldtrip_id=="F3"] <- 2009
com$year[com$fieldtrip_id=="F4"] <- 2010
com$year[com$fieldtrip_id=="F5"] <- 2011
com$year[com$fieldtrip_id=="F6"] <- 2012
com$year[com$fieldtrip_id=="F7"] <- 2013
names(com)[4] <- "spp"
names(com)[28] <- "area_cm2_mariana"
com <- com[c("colony_id", "spp", "year", "touch_number", "touch_outliner_name", "touch_taxon", "touch_growthform", "touch_length_cm", "competition", "touch_id", "competition_type", "outcome", "area_cm2_mariana")]

# competition_taxon: (I'd suggest keep, but it wasn't used in the analysis). Taxonomic identity of the competitor
# competition_growthform: (keep, used for the analysis). Competitor's growth form
# competition_type_old: delete
# competition_length_cm: (keep, used for the analysis). Length of the colony's perimeter that was involved in the competitive interaction.
# competition: (I'm not sure about this one. One option would be to keep only the observations that said "yes", the other option would be to change yes to "obvious" or "certain" and no to "uncertain" ?). The description could be "Confidence in classifying the interaction as competitive.
# standoff: (probably delete, this is already contained in the column "competition", although not all "no"s were standoffs.
# touch_flag: delete
# touch_notes: (probably delete)
# competition_type: (keep) Type of competitive encounter. "Overtop" : either the focal colony or a neighbor were partially covering the other colony on the planar view. "Digestion" : either colony had a white border or injury near the margin of another colony. "Overgrowth" : one of the colonies was growing on the surface of the other colony. (Definitions from the competition paper)
# outcome: Result of the competitive encounter. "won" : focal colony was overtopping, digesting or overgrowing the competition. "lost" : focal colony was being overtopped, digested or overgrown by the competitor.

# com_text <- paste0(com$colony_id, "_", com$spp, "_", com$year)
# gdat_text <- paste0(gdat$colony_id, "_", gdat$spp, "_", gdat$year)
# length(com_text %in% gdat_text)
# length(gdat_text %in% com_text)

com <- merge(com, dat, all.x=TRUE)
plot(area_cm2_mariana ~ area_cm2, com)
head(com)

com <- com[c("colony_id", "spp", "species", "year", "area_cm2", "touch_id", "touch_number", "touch_outliner_name", "touch_taxon", "touch_growthform", "touch_length_cm", "competition", "competition_type", "outcome")]
names(com) <- c("colony_id", "spp", "species", "year", "area_cm2", "competition_id", "competition_number", "competition_outliner_name", "competition_taxon", "competition_growthform", "competition_length_cm", "competition", "competition_type", "competition_outcome")

com$competition[com$competition=="yes"] <- "certain"
com$competition[com$competition=="yesyes"] <- "certain"
com$competition[com$competition=="no"] <- "uncertain"

com <- com[order(com$colony_id),]
com$species<-params$species[match(com$spp, params$spp)]
write.csv(com, "output/competition.csv", row.names=FALSE)


### FECUNDITY

fecundity<-read.csv("data/fecundity/Fecundity_Trimodal_2008-16.csv", as.is =TRUE)
areas <- read.csv("data/fecundity/area_fecund_trimodal_2009-16.csv", as.is =TRUE)[,c("id", "area_cm2")]

fec<-merge(fecundity, areas) # merges via colony ID 

fec <- fec[!(fec$id %in% c("F5_AC28", "F5_AD05")),] # Two colonies with bad outlines

fec$reproductive <- ifelse(fec$eggs==0, 0, 1)

# export
fec$branch<-ifelse(fec$branch=="na",NA,fec$branch)
colnames(fec)[c(5:7)] <- c("species","spp","colony")
fec$species <- params$species[match(fec$spp, params$spp)]
fec <- subset(fec, select=-c(trip_code, zone))

write.csv(fec, "output/fecundity.csv", row.names=FALSE)


# egg energy content and colony area

ec <- read.csv("data/polyp_egg/EggCarbon_Trimodal_2013-5.csv", as.is=TRUE)
areas <- read.csv("data/fecundity/Area_spawners_trimodal_2013-15.csv", as.is=TRUE)[,c("id", "area_cm2")]
ec <- merge(ec, areas)
ec <- subset(ec, select=-c(Trip_code))
colnames(ec)[4]<-"spp"
ec$species <- params$species[match(ec$spp, params$spp)]

write.csv(ec, "output/egg_energy.csv", row.names=FALSE)


# polyps per cm2 

pd <- read.csv("data/polyp_egg/polyp_density.csv", as.is=TRUE)
colnames(pd)[2] <- "spp"
pd$species <- params$species[match(pd$spp, params$spp)]
head(pd)
pd <- pd[,c("id","spp","species","cm2","polyps","polyps_cm2")]

write.csv(pd, "output/polyp_density.csv", row.names=FALSE)






### SIZE STRUCTURE

dat_F4 <- read.delim("data/size_structure/size_structure_output_master_2.txt")[,c("species", "area_cm2")]
dat_F4$year <- 2010

dat_F5 <- read.delim("data/size_structure/size_structure_output_master.txt")[,c("species", "area_cm2")]
dat_F5$year <- 2011

ss <- rbind(dat_F4, dat_F5)
ss <- ss[!is.na(ss$area_cm2),]
ss <- ss[ss$area_cm2 > 0,]

ss$species[ss$species=="Acropora fat dig"] <- "Acropora cf. digitifera"
ss$spp <- params$spp[match(ss$species, params$species)]

ss$species[ss$species=="Acropora nasuta cerealis"] <- "Acropora nasuta"
ss <- ss[ss$species!="Diploastrea sp",]

ss <- ss[,c("spp","species","year","area_cm2")]

write.csv(ss, "output/size_structure.csv", row.names=FALSE)

## Get photos

files <- dir("../trimodal/proj_data/output/tagged_outlines/")

head(obs)

for (i in 1:nrow(obs)) {
  temp <- files[grepl(obs$image_id[i], files)]
  file.copy(paste0("../trimodal/proj_data/output/tagged_outlines/", temp), "output/outline_images/")
}

files <- dir("data/tagged_outlines_files/")

for (i in 1:nrow(obs)) {
  temp <- files[grepl(obs$image_id[i], files)]
  file.copy(paste0("data/tagged_outlines_files/", temp), "output/outline_files/")
}



